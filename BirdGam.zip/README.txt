Controls

WASD/Arrows - Move
F - Action
R - restart